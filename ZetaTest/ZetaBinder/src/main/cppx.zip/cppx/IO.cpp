#include "IO.h"

list<IO::RelocateInfo> IO::relocate_rule;
list<string> IO::white_rule;

// Helper function to replace substrings in a path
string IO::replace(const string &str, const string &src, const string &dst) {
    string result = str;
    size_t pos = 0;
    while ((pos = result.find(src, pos)) != string::npos) {
        result.replace(pos, src.length(), dst);
        pos += dst.length();
    }
    return result;
}

// Check if a path is whitelisted
bool IO::isWhitelisted(const string &path) {
    for (const auto &rule : white_rule) {
        if (path.find(rule) != string::npos) {
            return true;
        }
    }
    return false;
}

// Get the redirected path based on rules
string IO::getRedirectedPath(const string &path) {
    if (isWhitelisted(path)) {
        return path;
    }

    for (const auto &rule : relocate_rule) {
        if (path.find(rule.targetPath) != string::npos) {
            string redirectedPath = replace(path, rule.targetPath, rule.relocatePath);
            log_print_debug("Redirecting path: %s -> %s", path.c_str(), redirectedPath.c_str());
            return redirectedPath;
        }
    }

    return path;
}

// Redirect path for JNI string
jstring IO::redirectPath(JNIEnv *env, jstring path) {
    if (!env || !path) {
        return nullptr;
    }

    const char *pathStr = env->GetStringUTFChars(path, JNI_FALSE);
    string redirectedPath = getRedirectedPath(pathStr);
    env->ReleaseStringUTFChars(path, pathStr);

    return env->NewStringUTF(redirectedPath.c_str());
}

// Redirect path for JNI object
jobject IO::redirectPath(JNIEnv *env, jobject path) {
    if (!env || !path) {
        return nullptr;
    }

    jclass fileClass = env->GetObjectClass(path);
    jmethodID getPathMethod = env->GetMethodID(fileClass, "getPath", "()Ljava/lang/String;");
    jstring pathStr = (jstring) env->CallObjectMethod(path, getPathMethod);

    jstring redirectedPathStr = redirectPath(env, pathStr);
    jmethodID constructor = env->GetMethodID(fileClass, "<init>", "(Ljava/lang/String;)V");
    return env->NewObject(fileClass, constructor, redirectedPathStr);
}

// Add a path to the whitelist
void IO::addWhiteList(const string &path) {
    if (!path.empty()) {
        white_rule.push_back(path);
        log_print_debug("Added to whitelist: %s", path.c_str());
    }
}

// Add a relocation rule
void IO::addRule(const string &targetPath, const string &relocatePath) {
    if (!targetPath.empty() && !relocatePath.empty()) {
        RelocateInfo info{targetPath, relocatePath};
        relocate_rule.push_back(info);
        log_print_debug("Added relocation rule: %s -> %s", targetPath.c_str(), relocatePath.c_str());
    }
}

// Handle scoped storage for Android 10+
#ifdef ANDROID_Q_PLUS
void IO::handleScopedStorage(JNIEnv *env, jstring path) {
    const char *pathStr = env->GetStringUTFChars(path, JNI_FALSE);
    log_print_debug("Handling scoped storage path: %s", pathStr);
    // Implement scoped storage handling logic here
    env->ReleaseStringUTFChars(path, pathStr);
}
#endif