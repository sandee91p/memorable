#include "RuntimeHook.h"
#import "JniHook/JniHook.h"
#include "BoxCore.h"
#include "Log.h"

// Hook for Android 10+ (Q and above)
HOOK_JNI(jstring, nativeLoadNew, JNIEnv *env, jobject obj, jstring name, jobject class_loader,
         jobject caller) {
    const char *nameC = env->GetStringUTFChars(name, JNI_FALSE);
    ALOGD("nativeLoad (Android 10+): %s", nameC);
    jstring result = orig_nativeLoadNew(env, obj, name, class_loader, caller);
    env->ReleaseStringUTFChars(name, nameC);
    return result;
}

// Hook for Android 9 and below
HOOK_JNI(jstring, nativeLoad, JNIEnv *env, jobject obj, jstring name, jobject class_loader) {
    const char *nameC = env->GetStringUTFChars(name, JNI_FALSE);
    ALOGD("nativeLoad (Android 9 and below): %s", nameC);
    jstring result = orig_nativeLoad(env, obj, name, class_loader);
    env->ReleaseStringUTFChars(name, nameC);
    return result;
}

void RuntimeHook::init(JNIEnv *env) {
    const char *className = "java/lang/Runtime";

    // Check Android API level to determine which nativeLoad method to hook
    if (BoxCore::getApiLevel() >= __ANDROID_API_Q__) {
        // Android 10+ (Q and above)
        JniHook::HookJniFun(env, className, "nativeLoad",
                            "(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/Class;)Ljava/lang/String;",
                            (void *) new_nativeLoadNew, (void **) (&orig_nativeLoadNew), true);
        ALOGD("RuntimeHook: Hooked nativeLoad (Android 10+)");
    } else {
        // Android 9 and below
        JniHook::HookJniFun(env, className, "nativeLoad",
                            "(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/String;",
                            (void *) new_nativeLoad, (void **) (&orig_nativeLoad), true);
        ALOGD("RuntimeHook: Hooked nativeLoad (Android 9 and below)");
    }
}