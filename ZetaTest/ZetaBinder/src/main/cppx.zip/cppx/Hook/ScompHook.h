#ifndef BLACKBOX_SCOMPHOOK_H
#define BLACKBOX_SCOMPHOOK_H

#include "BaseHook.h"

class ScompHook : public BaseHook {
public:
    static void init(JNIEnv *env);
};

#endif // BLACKBOX_SCOMPHOOK_H