#include "LinuxHook.h"
#include "IO.h"
#include "JniHook/JniHook.h"
#include "Log.h"

/*
 * Hook for access system call
 */
HOOK_JNI(jboolean, access, JNIEnv *env, jobject obj, jstring path, jint mode) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("access: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_access(env, obj, redirect, mode);
}

/*
 * Hook for chmod system call
 */
HOOK_JNI(void, chmod, JNIEnv *env, jobject obj, jstring path, jint mode) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("chmod: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_chmod(env, obj, redirect, mode);
}

/*
 * Hook for chown system call
 */
HOOK_JNI(void, chown, JNIEnv *env, jobject obj, jstring path, jint uid, jint gid) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("chown: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_chown(env, obj, redirect, uid, gid);
}

/*
 * Hook for execv system call
 */
HOOK_JNI(void, execv, JNIEnv *env, jobject obj, jstring filename, jobjectArray argv) {
    jstring redirect = IO::redirectPath(env, filename);
    const char *originalPath = env->GetStringUTFChars(filename, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("execv: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(filename, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_execv(env, obj, redirect, argv);
}

/*
 * Hook for execve system call
 */
HOOK_JNI(void, execve, JNIEnv *env, jobject obj, jstring filename, jobjectArray argv, jobjectArray envp) {
    jstring redirect = IO::redirectPath(env, filename);
    const char *originalPath = env->GetStringUTFChars(filename, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("execve: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(filename, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_execve(env, obj, redirect, argv, envp);
}

/*
 * Hook for getxattr system call
 */
HOOK_JNI(jbyteArray, getxattr, JNIEnv *env, jobject obj, jstring path, jstring name) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("getxattr: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_getxattr(env, obj, redirect, name);
}

/*
 * Hook for lchown system call
 */
HOOK_JNI(void, lchown, JNIEnv *env, jobject obj, jstring path, jint uid, jint gid) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("lchown: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_lchown(env, obj, redirect, uid, gid);
}

/*
 * Hook for link system call
 */
HOOK_JNI(void, link, JNIEnv *env, jobject obj, jstring oldPath, jstring newPath) {
    jstring redirectOldPath = IO::redirectPath(env, oldPath);
    jstring redirectNewPath = IO::redirectPath(env, newPath);
    const char *originalOldPath = env->GetStringUTFChars(oldPath, JNI_FALSE);
    const char *originalNewPath = env->GetStringUTFChars(newPath, JNI_FALSE);
    const char *redirectedOldPath = env->GetStringUTFChars(redirectOldPath, JNI_FALSE);
    const char *redirectedNewPath = env->GetStringUTFChars(redirectNewPath, JNI_FALSE);
    ALOGD("link: %s -> %s, %s -> %s", originalOldPath, redirectedOldPath, originalNewPath, redirectedNewPath);
    env->ReleaseStringUTFChars(oldPath, originalOldPath);
    env->ReleaseStringUTFChars(newPath, originalNewPath);
    env->ReleaseStringUTFChars(redirectOldPath, redirectedOldPath);
    env->ReleaseStringUTFChars(redirectNewPath, redirectedNewPath);
    return orig_link(env, obj, redirectOldPath, redirectNewPath);
}

/*
 * Hook for listxattr system call
 */
HOOK_JNI(jobjectArray, listxattr, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("listxattr: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_listxattr(env, obj, redirect);
}

/*
 * Hook for lstat system call
 */
HOOK_JNI(jobject, lstat, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("lstat: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_lstat(env, obj, redirect);
}

/*
 * Hook for mkdir system call
 */
HOOK_JNI(void, mkdir, JNIEnv *env, jobject obj, jstring path, jint mode) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("mkdir: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_mkdir(env, obj, redirect, mode);
}

/*
 * Hook for mkfifo system call
 */
HOOK_JNI(void, mkfifo, JNIEnv *env, jobject obj, jstring path, jint mode) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("mkfifo: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_mkfifo(env, obj, redirect, mode);
}

/*
 * Hook for open system call
 */
HOOK_JNI(jobject, open, JNIEnv *env, jobject obj, jstring path, jint flags, jint mode) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("open: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_open(env, obj, redirect, flags, mode);
}

/*
 * Hook for readlink system call
 */
HOOK_JNI(jstring, readlink, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("readlink: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_readlink(env, obj, redirect);
}

/*
 * Hook for realpath system call
 */
HOOK_JNI(jstring, realpath, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("realpath: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_realpath(env, obj, redirect);
}

/*
 * Hook for remove system call
 */
HOOK_JNI(void, remove, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("remove: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_remove(env, obj, redirect);
}

/*
 * Hook for removexattr system call
 */
HOOK_JNI(void, removexattr, JNIEnv *env, jobject obj, jstring path, jstring name) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("removexattr: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_removexattr(env, obj, redirect, name);
}

/*
 * Hook for rename system call
 */
HOOK_JNI(void, rename, JNIEnv *env, jobject obj, jstring oldPath, jstring newPath) {
    jstring redirectOldPath = IO::redirectPath(env, oldPath);
    jstring redirectNewPath = IO::redirectPath(env, newPath);
    const char *originalOldPath = env->GetStringUTFChars(oldPath, JNI_FALSE);
    const char *originalNewPath = env->GetStringUTFChars(newPath, JNI_FALSE);
    const char *redirectedOldPath = env->GetStringUTFChars(redirectOldPath, JNI_FALSE);
    const char *redirectedNewPath = env->GetStringUTFChars(redirectNewPath, JNI_FALSE);
    ALOGD("rename: %s -> %s, %s -> %s", originalOldPath, redirectedOldPath, originalNewPath, redirectedNewPath);
    env->ReleaseStringUTFChars(oldPath, originalOldPath);
    env->ReleaseStringUTFChars(newPath, originalNewPath);
    env->ReleaseStringUTFChars(redirectOldPath, redirectedOldPath);
    env->ReleaseStringUTFChars(redirectNewPath, redirectedNewPath);
    return orig_rename(env, obj, redirectOldPath, redirectNewPath);
}

/*
 * Hook for setxattr system call
 */
HOOK_JNI(void, setxattr, JNIEnv *env, jobject obj, jstring path, jstring name, jbyteArray value, jint flags) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("setxattr: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_setxattr(env, obj, redirect, name, value, flags);
}

/*
 * Hook for stat system call
 */
HOOK_JNI(jobject, stat, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("stat: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_stat(env, obj, redirect);
}

/*
 * Hook for statvfs system call
 */
HOOK_JNI(jobject, statvfs, JNIEnv *env, jobject obj, jstring path) {
    jstring redirect = IO::redirectPath(env, path);
    const char *originalPath = env->GetStringUTFChars(path, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("statvfs: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(path, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_statvfs(env, obj, redirect);
}

/*
 * Hook for symlink system call
 */
HOOK_JNI(void, symlink, JNIEnv *env, jobject obj, jstring oldPath, jstring newPath) {
    jstring redirectOldPath = IO::redirectPath(env, oldPath);
    jstring redirectNewPath = IO::redirectPath(env, newPath);
    const char *originalOldPath = env->GetStringUTFChars(oldPath, JNI_FALSE);
    const char *originalNewPath = env->GetStringUTFChars(newPath, JNI_FALSE);
    const char *redirectedOldPath = env->GetStringUTFChars(redirectOldPath, JNI_FALSE);
    const char *redirectedNewPath = env->GetStringUTFChars(redirectNewPath, JNI_FALSE);
    ALOGD("symlink: %s -> %s, %s -> %s", originalOldPath, redirectedOldPath, originalNewPath, redirectedNewPath);
    env->ReleaseStringUTFChars(oldPath, originalOldPath);
    env->ReleaseStringUTFChars(newPath, originalNewPath);
    env->ReleaseStringUTFChars(redirectOldPath, redirectedOldPath);
    env->ReleaseStringUTFChars(redirectNewPath, redirectedNewPath);
    return orig_symlink(env, obj, redirectOldPath, redirectNewPath);
}

/*
 * Hook for unlink system call
 */
HOOK_JNI(void, unlink, JNIEnv *env, jobject obj, jstring pathname) {
    jstring redirect = IO::redirectPath(env, pathname);
    const char *originalPath = env->GetStringUTFChars(pathname, JNI_FALSE);
    const char *redirectedPath = env->GetStringUTFChars(redirect, JNI_FALSE);
    ALOGD("unlink: %s -> %s", originalPath, redirectedPath);
    env->ReleaseStringUTFChars(pathname, originalPath);
    env->ReleaseStringUTFChars(redirect, redirectedPath);
    return orig_unlink(env, obj, redirect);
}

void LinuxHook::init(JNIEnv *env) {
    JniHook::HookJniFun(env, "libcore/io/Linux", "access", "(Ljava/lang/String;I)Z",
                        (void *) new_access, (void **) (&orig_access), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "chmod", "(Ljava/lang/String;I)V",
                        (void *) new_chmod, (void **) (&orig_chmod), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "chown", "(Ljava/lang/String;II)V",
                        (void *) new_chown, (void **) (&orig_chown), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "execv", "(Ljava/lang/String;[Ljava/lang/String;)V",
                        (void *) new_execv, (void **) (&orig_execv), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "execve", "(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)V",
                        (void *) new_execve, (void **) (&orig_execve), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "getxattr", "(Ljava/lang/String;Ljava/lang/String;)[B",
                        (void *) new_getxattr, (void **) (&orig_getxattr), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "lchown", "(Ljava/lang/String;II)V",
                        (void *) new_lchown, (void **) (&orig_lchown), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "link", "(Ljava/lang/String;Ljava/lang/String;)V",
                        (void *) new_link, (void **) (&orig_link), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "listxattr", "(Ljava/lang/String;)[Ljava/lang/String;",
                        (void *) new_listxattr, (void **) (&orig_listxattr), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "lstat", "(Ljava/lang/String;)Landroid/system/StructStat;",
                        (void *) new_lstat, (void **) (&orig_lstat), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "mkdir", "(Ljava/lang/String;I)V",
                        (void *) new_mkdir, (void **) (&orig_mkdir), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "mkfifo", "(Ljava/lang/String;I)V",
                        (void *) new_mkfifo, (void **) (&orig_mkfifo), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "open", "(Ljava/lang/String;II)Ljava/io/FileDescriptor;",
                        (void *) new_open, (void **) (&orig_open), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "readlink", "(Ljava/lang/String;)Ljava/lang/String;",
                        (void *) new_readlink, (void **) (&orig_readlink), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "realpath", "(Ljava/lang/String;)Ljava/lang/String;",
                        (void *) new_realpath, (void **) (&orig_realpath), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "remove", "(Ljava/lang/String;)V",
                        (void *) new_remove, (void **) (&orig_remove), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "removexattr", "(Ljava/lang/String;Ljava/lang/String;)V",
                        (void *) new_removexattr, (void **) (&orig_removexattr), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "rename", "(Ljava/lang/String;Ljava/lang/String;)V",
                        (void *) new_rename, (void **) (&orig_rename), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "stat", "(Ljava/lang/String;)Landroid/system/StructStat;",
                        (void *) new_stat, (void **) (&orig_stat), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "statvfs", "(Ljava/lang/String;)Landroid/system/StructStatVfs;",
                        (void *) new_statvfs, (void **) (&orig_statvfs), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "symlink", "(Ljava/lang/String;Ljava/lang/String;)V",
                        (void *) new_symlink, (void **) (&orig_symlink), false);

    JniHook::HookJniFun(env, "libcore/io/Linux", "unlink", "(Ljava/lang/String;)V",
                        (void *) new_unlink, (void **) (&orig_unlink), false);

    ALOGD("LinuxHook initialized");
}