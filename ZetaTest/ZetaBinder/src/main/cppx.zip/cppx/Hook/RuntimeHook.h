#ifndef BLACKBOX_RUNTIMEHOOK_H
#define BLACKBOX_RUNTIMEHOOK_H

#include "BaseHook.h"

class RuntimeHook : public BaseHook {
public:
    static void init(JNIEnv *env);
};

#endif // BLACKBOX_RUNTIMEHOOK_H