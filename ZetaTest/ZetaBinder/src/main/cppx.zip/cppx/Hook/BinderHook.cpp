#include "BinderHook.h"
#include "BoxCore.h"
#include "JniHook/JniHook.h"
#include "Log.h"

/*
 * Hook for getCallingUid method
 */
HOOK_JNI(jint, getCallingUid, JNIEnv *env, jobject obj) {
    // Call the original method to get the original UID
    jint origUid = orig_getCallingUid(env, obj);

    // Modify the UID using BoxCore
    jint modifiedUid = BoxCore::getCallingUid(origUid);

    // Log the original and modified UID for debugging
    ALOGD("getCallingUid: original UID = %d, modified UID = %d", origUid, modifiedUid);

    // Return the modified UID
    return modifiedUid;
}

void BinderHook::init(JNIEnv *env) {
    const char *className = "android/os/Binder";

    // Hook the getCallingUid method
    JniHook::HookJniFun(env, className, "getCallingUid", "()I",
                        (void *) new_getCallingUid, (void **) (&orig_getCallingUid), true);

    ALOGD("BinderHook initialized");
}