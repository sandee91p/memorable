#ifndef BLACKBOX_IO_H
#define BLACKBOX_IO_H

#if defined(__LP64__)
#define LINKER_PATH_L "/system/bin/linker64"
#define LINKER_PATH_Q "/apex/com.android.runtime/bin/linker64"
#define LIBC_PATH_L "/system/lib64/libc.so"
#define LIBC_PATH_Q "/apex/com.android.runtime/lib64/bionic/libc.so"
#else
#define LINKER_PATH_L "/system/bin/linker"
#define LINKER_PATH_Q "/apex/com.android.runtime/bin/linker"
#define LIBC_PATH_L "/system/lib/libc.so"
#define LIBC_PATH_Q "/apex/com.android.runtime/lib/bionic/libc.so"
#endif

#include <jni.h>
#include <list>
#include <string>
#include <iostream>
#include "BoxCore.h"
#include "Log.h"

using namespace std;

class IO {
public:
    struct RelocateInfo {
        string targetPath;
        string relocatePath;
    };

    static void init(JNIEnv *env);

    static void addRule(const string &targetPath, const string &relocatePath);

    static void addWhiteList(const string &path);

    static jstring redirectPath(JNIEnv *env, jstring path);

    static jobject redirectPath(JNIEnv *env, jobject path);

    static void replaceFD(JNIEnv *env, jobject fd);

    // Added for Android 10+ compatibility
#ifdef ANDROID_Q_PLUS
    static void handleScopedStorage(JNIEnv *env, jstring path);
#endif

private:
    static list<RelocateInfo> relocate_rule;
    static list<string> white_rule;

    static string replace(const string &str, const string &src, const string &dst);
    static bool isWhitelisted(const string &path);
    static string getRedirectedPath(const string &path);
};

#endif // BLACKBOX_IO_H